-- vamos a mostrar la pantalla los datos registrados en la tabla de socios

SELECT * FROM gimnasio.socios;

SELECT * FROM gimnasio.tarjetas;

SELECT * FROM gimnasio.planes;

SELECT * FROM gimnasio.entrenadores;  

SELECT * FROM gimnasio.clases;

SELECT * FROM gimnasio.asistencias;

SELECT * FROM gimnasio.vigentes;